# CHANGELOG

## [2.2.0] 2021-01-21

### ADDED

- Added more tokens; we're up to 138 now!